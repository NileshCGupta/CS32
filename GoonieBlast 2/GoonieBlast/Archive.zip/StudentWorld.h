#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "GameConstants.h"
#include <vector>
#include <string>
#include <map>
using namespace std;

class Actor;
class Player;
class Level;

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class StudentWorld : public GameWorld
{
	public:
		StudentWorld(std::string assetDir)
		 : GameWorld(assetDir), time(1500), main(0), sub(0)
		{
		}
		~StudentWorld() {cleanUp();};
		virtual int init();
		virtual int move();
		virtual void cleanUp();
		virtual int getCurrentSubLevel();
		int loadLevel(int main, int sub);
		bool isObstacle(int x, int y);
		bool isPlayerLoc(int x, int y);
		void levelCompleted(bool b) {levelComplete = b;}
		void addActor(Actor* a) {actors.push_back(a);}
		vector<Actor*> anyOtherActors(int x, int y);
		void transport(int sub);
		
	private:
		vector<Actor*> actors;
		Player *playa;
		int time;
		int main, sub;
		bool levelComplete;
//		Level* current;
};

#endif // STUDENTWORLD_H_
