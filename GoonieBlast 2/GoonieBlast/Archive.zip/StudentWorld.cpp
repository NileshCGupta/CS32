#include "StudentWorld.h"
#include <string>
#include "Level.h"
#include "Actor.h"
#include <sstream>
#include <iostream>
using namespace std;

//int StudentWorld::loadLevel(int main, int sub)
//{
//	ostringstream os;
//	os << "level";
//	if(main < 10)
//		os << "0";
//	
//	os << main;
//	
//	if(sub != 0)
//		os << "_" << sub;
//	
//	os << ".dat";
//	string curLevel = os.str();
//	
//	Level lev(assetDirectory());
//	Level::LoadResult result = lev.loadLevel(curLevel);
//	
//	if (result == Level::load_fail_file_not_found ||
//		result == Level:: load_fail_bad_format)
//		return -1; // something bad happened!
//	// otherwise the load was successful and you can access the
//	// contents of the level – here’s an example
//	
//	for(int x = 0; x < VIEW_WIDTH - 1; x++)
//		for(int y = 0; y < VIEW_HEIGHT - 1; y++)
//		{
//			Level::MazeEntry item = lev.getContentsOf(x, y, sub);
//			if (item == Level::player)
//			{
//				Player* p = new Player(x, y, sub, this);
//				actors.push_back(p);
//			}
//			if (item == Level::wall)
//			{
//				Wall* w = new Wall(x, y, sub, this);
//				actors.push_back(w);
//			}
//			
//		}
//	current = &lev;
//	current->loadLevel(curLevel);
//	return 0;
//}

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}

// Students:  Add code to this file (if you wish), StudentWorld.h, Actor.h and Actor.cpp

int StudentWorld::init()
{
	ostringstream os;
	os << "level";
	if(main < 10)
		os << "0";
	
	os << main;
	
	if(sub != 0)
		os << "_" << sub;
	
	os << ".dat";
	string curLevel = os.str();

	Level lev(assetDirectory());
	Level::LoadResult result = lev.loadLevel(curLevel);
	
	if (result == Level::load_fail_file_not_found ||
		result == Level:: load_fail_bad_format)
		return -1; // something bad happened!
			// otherwise the load was successful and you can access the
			// contents of the level – here’s an example
	
	for(int x = 0; x < VIEW_WIDTH; x++)
	{
		for(int y = 0; y < VIEW_HEIGHT; y++)
		{
			Level::MazeEntry item = lev.getContentsOf(x, y, 0);
			if (item == Level::player)
			{
				Player *p = new Player(x, y, 0, this);
				playa = p;
				actors.push_back(p);
			}
			if (item == Level::wall)
			{
				Wall *w = new Wall(x, y, 0, this);
				actors.push_back(w);
			}
			if (item == Level::jewel)
			{
				Jewel *j = new Jewel(x, y, 0, this);
				actors.push_back(j);
			}
			
		}
	}

    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
	for(int i = 0; i < actors.size(); i++)
	{
		actors.at(i)->doSomething();
		if(playa->isDead())
			return GWSTATUS_PLAYER_DIED;
	}
	
	for(int i = 0; i < actors.size(); i++)
	{
		if(actors.at(i)->isDead())
		{
			delete actors.at(i);
			actors.erase(actors.begin() + i);
		}
	}
	
	time--;
	return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
	for(int i = 0; i < actors.size(); i++)
		delete actors[i];
}

int StudentWorld::getCurrentSubLevel()
{
    return sub;
}

bool StudentWorld::isObstacle(int x, int y)
{
	for(int i = 0; i < actors.size(); i++)
		if(actors[i]->getX() == x && actors[i]->getY() == y)
			if(actors[i]->getID() == IID_WALL)
				return true;
	
	return false;
}

bool StudentWorld::isPlayerLoc(int x, int y)
{
	return playa->getX() == x && playa->getY() == y;
}

vector<Actor*> StudentWorld::anyOtherActors(int x, int y)
{
	vector<Actor*> otherActors;
	for(int i = 0; i < actors.size(); i++)
		if(actors[i]->getX() == x && actors[i]->getY() == y)
			otherActors.push_back(actors[i]);
	
	return otherActors;
}

