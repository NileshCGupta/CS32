#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include "StudentWorld.h"

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

class Actor: public GraphObject
{
    public:
        Actor(int image_ID, int x, int y, Direction start = none, int sub_level = 0, StudentWorld* sw = nullptr):
        GraphObject(image_ID, x, y, start, sub_level) {world = sw;};
        virtual void doSomething() = 0;
		virtual bool isDead() = 0;
		StudentWorld* getWorld() {return world;};
		virtual void damage() = 0;
	
	private:
		StudentWorld* world;
	
};

class Player: public Actor
{
    public:
        Player(int x, int y, int sub_level, StudentWorld* sw):
        Actor(0, x, y, right, sub_level, sw)
        {hp = 20; ammo = 0; setVisible(true);};
		void doSomething();
		bool isDead() {return hp == 0;}
		void damage() {hp -= 2;}
	
    private:
        int hp;
        int ammo;
};

class Wall: public Actor
{
    public:
        Wall(int x, int y, int sub_level, StudentWorld* sw):
        Actor(6, x, y, none, sub_level, sw)
        {setVisible(true);};
		void doSomething() {};
		bool isDead() {return false;}
		void damage() {}
};

class Gate: public Actor
{
	public:
		Gate(int x, int y, int sub_level, StudentWorld *sw):
		Actor(8, x, y, none, sub_level, sw) {gateNum = sub_level; hp = 1; setVisible(true);}
		void doSomething();
		bool isDead() {return hp == 0;}
		void damage() {}
		
	private:
		int gateNum;
		int hp;
	
};

class Jewel: public Actor
{
	public:
		Jewel(int x, int y, int sub_level, StudentWorld *sw):
		Actor(9, x, y, none, sub_level, sw) {hp = 1; setVisible(true);}
		void doSomething();
		bool isDead() {return hp == 0;}
		void damage() {}
	
	private:
		int hp;
};

class Hostage: public Actor
{
	public:
		Hostage(int x, int y, int sub_level, StudentWorld *sw):
		Actor(3, x, y, none, sub_level, sw) {hp = 1; setVisible(true);}
		void doSomething();
		bool isDead() {return hp == 0;}
		void damage() {}
	
	private:
		int hp;
	
};

class Exit: public Actor
{
	public:
		Exit(int x, int y, StudentWorld *sw):
		Actor(7, x, y, none, 0, sw) {}
		void doSomething();
		bool isDead() {return false;}
		void damage() {}
		void reveal();
};

class Bullet: public Actor
{
	public:
		Bullet(int x, int y, Direction dir, int sub_level, StudentWorld* sw):
		Actor(5, x, y, dir, sub_level, sw) {hp = 1; setVisible(true);};
		void doSomething();
		bool isDead() {return hp == 0;}
		void damage() {}

	private:
		int hp;
};

class SnarlBot: public Actor
{
	
};

class KleptoBot: public Actor
{
	
};

class KleptoBotFactory: public Actor
{
	
};

#endif // ACTOR_H_
