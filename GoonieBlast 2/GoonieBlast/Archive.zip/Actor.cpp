#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file (if you wish), Actor.h, StudentWorld.h, and StudentWorld.cpp

void Player::doSomething()
{
	if(isDead())
		return;
	int ch;
	if(getWorld()->getKey(ch))
	{
		// user hit a key
		switch(ch)
		{
			case KEY_PRESS_LEFT:
				if(getWorld()->isObstacle(getX() - 1, getY()))
					break;
				moveTo(getX() - 1, getY());
				setDirection(left);
				break;
				
			case KEY_PRESS_RIGHT:
				if(getWorld()->isObstacle(getX() + 1, getY()))
					break;
				moveTo(getX() + 1, getY());
				setDirection(right);
				break;
				
			case KEY_PRESS_UP:
				if(getWorld()->isObstacle(getX(), getY() + 1))
					break;
				moveTo(getX(), getY() + 1);
				setDirection(up);
				break;
				
			case KEY_PRESS_DOWN:
				if(getWorld()->isObstacle(getX(), getY() - 1))
					break;
				moveTo(getX(), getY() - 1);
				setDirection(down);
				break;
				
			case KEY_PRESS_SPACE:
				// add new bullet in square in front of player
				if(ammo != 0)
				{
					Direction dir = getDirection();
					switch(dir)
					{
						case up:
						{
							Bullet *bill = new Bullet(getX(), getY() + 1, dir, 0, getWorld());
							getWorld()->addActor(bill);
							break;
						}
						case down:
						{
							Bullet *bill = new Bullet(getX(), getY() - 1, dir, 0, getWorld());
							getWorld()->addActor(bill);
							break;
						}
						case left:
						{
							Bullet *bill = new Bullet(getX(), getY() - 1, dir, 0, getWorld());
							getWorld()->addActor(bill);
							break;
						}
						case right:
						{
							Bullet *bill = new Bullet(getX(), getY() + 1, dir, 0, getWorld());
							getWorld()->addActor(bill);
							break;
						}
						default:
							break;
					}
					ammo--;
				}
				break;
				
			case KEY_PRESS_ESCAPE:
				hp = 0;
				break;
			
		}
	}
}

void Bullet::doSomething()
{
	if(isDead())
		return;
	
	vector<Actor*> sameSquare = getWorld()->anyOtherActors(getX(), getY());
	if(sameSquare.size() != 1)
		for(int i = 0; i < sameSquare.size(); i++)
		{
		// checks if other actors on the same square can be damaged
			if(sameSquare[i]->getID() == IID_PLAYER || sameSquare[i]->getID() == IID_KLEPTOBOT || sameSquare[i]->getID() == IID_SNARLBOT)
			{
				sameSquare[i]->damage();
				hp = 0;
				return;
			}
			if(sameSquare[i]->getID() == IID_WALL || sameSquare[i]->getID() == IID_ROBOT_FACTORY)
			{
				hp = 0;
				return;
			}
		}
	
	// if there are no interactable actors in its square then it moves in its current direction
	Direction dir = getDirection();
	switch(dir)
	{
		case up:
			moveTo(getX(), getY() + 1);
			break;
		case down:
			moveTo(getX(), getY() - 1);
			break;
		case left:
			moveTo(getX() - 1, getY());
			break;
		case right:
			moveTo(getX() + 1, getY());
			break;
		default:
			break;
	}
	
	// checks if there are any interactable actors in its new square
	sameSquare = getWorld()->anyOtherActors(getX(), getY());
	if(sameSquare.size() != 1)
		for(int i = 0; i < sameSquare.size(); i++)
		{
			// checks if other actors on the same square can be damaged
			if(sameSquare[i]->getID() == IID_PLAYER || sameSquare[i]->getID() == IID_KLEPTOBOT || sameSquare[i]->getID() == IID_SNARLBOT)
			{
				sameSquare[i]->damage();
				hp = 0;
				return;
			}
			if(sameSquare[i]->getID() == IID_WALL || sameSquare[i]->getID() == IID_ROBOT_FACTORY)
			{
				hp = 0;
				return;
			}
		}
}

void Gate::doSomething()
{
	if(isDead())
		return;
	
	if(getWorld()->isPlayerLoc(getX(), getY()))
	{
		hp = 0;
//		getWorld()->transport(gateNum);
	}
}

void Jewel::doSomething()
{
	if(isDead())
		return;
	
	if(getWorld()->isPlayerLoc(getX(), getY()))
	{
		getWorld()->increaseScore(100);
		hp = 0;
		getWorld()->playSound(5);
	}
}

void Hostage::doSomething()
{
	if(isDead())
		return;
	
	if(getWorld()->isPlayerLoc(getX(), getY()))
	{
		hp = 0;
		getWorld()->playSound(5);
	}
}

void Exit::doSomething()
{
	if(getWorld()->isPlayerLoc(getX(), getY()) && isVisible())
	{
		getWorld()->playSound(7);
		getWorld()->increaseScore(1000);
		getWorld()->levelCompleted(true);
	}
}
